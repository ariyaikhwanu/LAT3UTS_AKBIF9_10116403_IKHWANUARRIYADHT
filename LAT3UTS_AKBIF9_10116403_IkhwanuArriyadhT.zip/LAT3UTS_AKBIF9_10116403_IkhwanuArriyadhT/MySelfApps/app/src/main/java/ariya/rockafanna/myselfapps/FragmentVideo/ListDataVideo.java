package ariya.rockafanna.myselfapps.FragmentVideo;

public class ListDataVideo {
        private String gmbr;

        public ListDataVideo (String gmbr) {

            this.gmbr = gmbr;

        }



        public String getGmbr() {
        return gmbr;
    }

        public void setGmbr(String gmbr)  { this.gmbr = gmbr;}

}
